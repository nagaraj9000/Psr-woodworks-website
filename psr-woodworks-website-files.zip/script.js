// Add the PSR WOODWORKS WhatsApp number in international format.
// Example for India: 919876543210 (country code + number, digits only).
const WHATSAPP_NUMBER = "91XXXXXXXXXX";

const menu = document.getElementById("menu");
const nav = document.getElementById("nav");
if (menu && nav) {
  menu.addEventListener("click", () => nav.classList.toggle("open"));
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => nav.classList.remove("open")));
}
document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("enquiry").addEventListener("submit", event => {
  event.preventDefault();
  const note = document.getElementById("formnote");
  if (WHATSAPP_NUMBER.includes("X")) {
    note.textContent = "Setup needed: replace 91XXXXXXXXXX in script.js with the PSR WOODWORKS WhatsApp number, then save.";
    return;
  }
  const data = new FormData(event.currentTarget);
  const message = [
    "Hello PSR WOODWORKS, I would like to enquire.",
    "Name: " + data.get("name"),
    "Phone: " + data.get("phone"),
    "Service: " + data.get("service"),
    "Project details: " + (data.get("message") || "Not provided")
  ].join("\\n");
  window.open("https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(message), "_blank", "noopener,noreferrer");
});
